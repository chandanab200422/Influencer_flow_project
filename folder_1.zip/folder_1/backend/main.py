from fastapi import FastAPI, HTTPException, Request, Header,Query
from pydantic import BaseModel
import requests
import firebase_admin
from firebase_admin import credentials, auth, firestore
import pandas as pd
from database import get_connection, return_connection
from typing import Optional, List
from datetime import date
from dotenv import load_dotenv
import os
import google.generativeai as genai
# === Initialize FastAPI App ===
app = FastAPI()

# === Firebase Setup ===
FIREBASE_API_KEY = "AIzaSyBeo38AA51KuqV9_wBDISAQlITSlUeV60A"  # Replace with your actual API key

cred = credentials.Certificate("servicekey.json")  # Ensure this file exists and is valid
firebase_admin.initialize_app(cred)
db = firestore.client()  # ✅ Firestore client initialized

# === Firebase Auth URLs ===
FIREBASE_SIGNUP_URL = f"https://identitytoolkit.googleapis.com/v1/accounts:signUp?key={FIREBASE_API_KEY}"
FIREBASE_LOGIN_URL = f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={FIREBASE_API_KEY}"

# === Models ===
class AuthRequest(BaseModel):
    email: str
    password: str

class CategoryRequest(BaseModel):
    categories: list[str] = []

# === Root Test Endpoint ===
@app.get("/")
def root():
    return {"message": "Hello World"}

# === Sign Up Endpoint ===
@app.post("/signup")
def signup(auth_data: AuthRequest):
    payload = {
        "email": auth_data.email,
        "password": auth_data.password,
        "returnSecureToken": True
    }
    res = requests.post(FIREBASE_SIGNUP_URL, json=payload)
    if res.status_code != 200:
        raise HTTPException(status_code=400, detail=res.json().get("error", {}).get("message", "Signup failed"))
    return res.json()  # Returns idToken, localId, etc.

# === Login Endpoint ===
@app.post("/login")
def login(auth_data: AuthRequest):
    payload = {
        "email": auth_data.email,
        "password": auth_data.password,
        "returnSecureToken": True
    }
    res = requests.post(FIREBASE_LOGIN_URL, json=payload)
    if res.status_code != 200:
        raise HTTPException(status_code=400, detail=res.json().get("error", {}).get("message", "Login failed"))
    return res.json()  # Returns idToken, localId, etc.

# === Register User Categories (Protected Endpoint) ===
@app.post("/register-user")
def register_user(request: CategoryRequest, authorization: str = Header(...)):
    try:
        # Extract token from Authorization header
        id_token = authorization.split(" ")[1]
        decoded_token = auth.verify_id_token(id_token)
        user_id = decoded_token["uid"]

        selected_categories = request.categories if request.categories else ["not given"]

        # Store in Firestore
        db.collection("users").document(user_id).set({
            "categories": selected_categories
        })

        return {"message": "User registered with categories", "categories": selected_categories}

    except Exception as e:
        print("❌ Error in /register-user:", e)
        raise HTTPException(status_code=500, detail="Internal Server Error")

@app.get("/creators")
def get_creators(
    location: Optional[List[str]] = Query(None),   # multi-select
    niche: Optional[List[str]] = Query(None),      # multi-select
    platforms: Optional[List[str]] = Query(None),  # multi-select

    followers_min: Optional[int] = None,
    followers_max: Optional[int] = None,

    avg_views_min: Optional[int] = None,
    avg_views_max: Optional[int] = None,

    product_sales_min: Optional[float] = None,  # if numeric, else skip
    product_sales_max: Optional[float] = None,  # else treat as text or skip

    product_price_min: Optional[float] = None,
    product_price_max: Optional[float] = None,

    engagement_rate_min: Optional[float] = None,
    engagement_rate_max: Optional[float] = None,

    product_rating_min: Optional[float] = None,
    product_rating_max: Optional[float] = None,

    endorsement_date_start: Optional[date] = None,
    endorsement_date_end: Optional[date] = None,

    hashtags: Optional[str] = None,   # simple text match, e.g. '#fashion'
    languages: Optional[str] = None   # text match, e.g. 'English'
):
    conn = get_connection()
    cursor = conn.cursor()

    query = "SELECT * FROM creators WHERE TRUE"
    params = []

    # Multi-select filters (IN with ILIKE)
    if location:
        query += " AND (" + " OR ".join(["location ILIKE %s"] * len(location)) + ")"
        params.extend([f"%{loc}%" for loc in location])

    if niche:
        query += " AND (" + " OR ".join(["niche ILIKE %s"] * len(niche)) + ")"
        params.extend([f"%{n}%" for n in niche])

    if platforms:
        query += " AND (" + " OR ".join(["platforms ILIKE %s"] * len(platforms)) + ")"
        params.extend([f"%{p}%" for p in platforms])

    # Range filters
    if followers_min is not None:
        query += " AND followers >= %s"
        params.append(followers_min)
    if followers_max is not None:
        query += " AND followers <= %s"
        params.append(followers_max)

    if avg_views_min is not None:
        query += " AND avg_views >= %s"
        params.append(avg_views_min)
    if avg_views_max is not None:
        query += " AND avg_views <= %s"
        params.append(avg_views_max)

    # If product_sales is numeric (you must confirm this!)
    if product_sales_min is not None:
        query += " AND product_sales::numeric >= %s"
        params.append(product_sales_min)
    if product_sales_max is not None:
        query += " AND product_sales::numeric <= %s"
        params.append(product_sales_max)

    if product_price_min is not None:
        query += " AND product_price >= %s"
        params.append(product_price_min)
    if product_price_max is not None:
        query += " AND product_price <= %s"
        params.append(product_price_max)

    # Threshold / slider filters
    if engagement_rate_min is not None:
        query += " AND engagement_rate >= %s"
        params.append(engagement_rate_min)
    if engagement_rate_max is not None:
        query += " AND engagement_rate <= %s"
        params.append(engagement_rate_max)

    if product_rating_min is not None:
        query += " AND product_rating >= %s"
        params.append(product_rating_min)
    if product_rating_max is not None:
        query += " AND product_rating <= %s"
        params.append(product_rating_max)

    # Date range
    if endorsement_date_start is not None:
        query += " AND endorsement_date >= %s"
        params.append(endorsement_date_start)
    if endorsement_date_end is not None:
        query += " AND endorsement_date <= %s"
        params.append(endorsement_date_end)

    # Text/tag matching (simple ILIKE)
    if hashtags:
        query += " AND hashtags ILIKE %s"
        params.append(f"%{hashtags}%")
    if languages:
        query += " AND languages ILIKE %s"
        params.append(f"%{languages}%")

    cursor.execute(query, tuple(params))
    rows = cursor.fetchall()

    columns = [desc[0] for desc in cursor.description]
    data = [dict(zip(columns, row)) for row in rows]

    cursor.close()
    return_connection(conn)

    return {"creators": data}


def analyze_promotion_potential(creators: list, product_name: str) -> dict:
    """
    Given a list of creators and a product name,
    analyze and estimate reach and suitability of each creator.

    Return a summary report.
    """
    report = []

    # Simple example scoring logic
    for c in creators:
        # Match product category or best_product to product_name or keywords in it
        product_fit = 1 if product_name.lower() in (c.get('best_product') or '').lower() else 0

        # Estimate reach = followers * engagement_rate (simplified)
        estimated_reach = c.get('followers', 0) * (c.get('engagement_rate', 0) / 100)

        # Score can combine product fit + estimated reach + niche relevance (expandable)
        score = product_fit * 1000 + estimated_reach

        report.append({
            "creator_id": c['creator_id'],
            "name": c['name'],
            "username": c['username'],
            "estimated_reach": int(estimated_reach),
            "product_fit": bool(product_fit),
            "score": score
        })

    # Sort by score descending
    report.sort(key=lambda x: x['score'], reverse=True)

    return {
        "product": product_name,
        "analysis_count": len(report),
        "report": report
    }

class Creator(BaseModel):
    creator_id: int
    name: str
    username: str
    followers: int
    engagement_rate: float
    best_product: str
    niche: str
    # add other fields as needed

class AnalysisRequest(BaseModel):
    product_name: str
    creators: List[Creator]

@app.post("/analyze-promotion")
def analyze_promotion(data: AnalysisRequest):
    creators = [c.dict() for c in data.creators]
    product_name = data.product_name

    result = analyze_promotion_potential(creators, product_name)
    return result

load_dotenv()
genai.configure(api_key=os.getenv("AIzaSyBG5n4UncahMagBlcBod4vqjtkIP-2y5wQ"))

class ChatQuery(BaseModel):
    query: str

@app.post("/ask")
def ask_gemini(query: ChatQuery):
    try:
        model = genai.GenerativeModel("gemini-pro")
        chat = model.start_chat()
        response = chat.send_message(query.query)
        return {"response": response.text.strip()}
    except Exception as e:
        print("❌ Error in /ask:", str(e))
        raise HTTPException(status_code=500, detail="Gemini API call failed")