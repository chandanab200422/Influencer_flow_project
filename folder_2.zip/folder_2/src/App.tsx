import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import CreatorDiscovery from './pages/CreatorDiscovery';
import CreatorProfile from './pages/CreatorProfile';
import Campaign from './pages/Campaign';

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/creators" element={<CreatorDiscovery />} />
          <Route path="/creator/:id" element={<CreatorProfile />} />
          <Route path="/campaign" element={<Campaign />} />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;