declare module 'react-simple-chatbot' {
  import * as React from 'react';

  export interface Step {
    id: string;
    message?: string;
    user?: boolean;
    trigger?: string | number;
    options?: { value: string | number; label: string; trigger: string | number }[];
    end?: boolean;
  }

  export interface ChatBotProps {
    steps: Step[];
    handleEnd?: (data: any) => void;
    hideBotAvatar?: boolean;
    hideUserAvatar?: boolean;
    placeholder?: string;
    botAvatar?: string;
    userAvatar?: string;
    headerTitle?: string;
    recognitionEnable?: boolean;
    recognitionLang?: string;
    speechSynthesis?: boolean;
    style?: React.CSSProperties;
    contentStyle?: React.CSSProperties;
    floating?: boolean;
  }

  const ChatBot: React.FC<ChatBotProps>;

  export default ChatBot;
}
