import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Search, X } from 'lucide-react';

interface RangeFilterProps {
  label: string;
  min: number;
  max: number;
  step?: number;
  valuePrefix?: string;
  valueSuffix?: string;
  onChange: (min: number, max: number) => void;
}

const RangeFilter: React.FC<RangeFilterProps> = ({
  label,
  min,
  max,
  step = 1,
  valuePrefix = '',
  valueSuffix = '',
  onChange,
}) => {
  const [minValue, setMinValue] = useState<number>(min);
  const [maxValue, setMaxValue] = useState<number>(max);

  const handleMinChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (value <= maxValue) {
      setMinValue(value);
      onChange(value, maxValue);
    }
  };

  const handleMaxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (value >= minValue) {
      setMaxValue(value);
      onChange(minValue, value);
    }
  };

  return (
    <div className="mb-4">
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      <div className="flex items-center space-x-2">
        <div className="w-1/2">
          <input
            type="number"
            value={minValue}
            onChange={handleMinChange}
            min={min}
            max={max}
            step={step}
            className="w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500 sm:text-sm"
          />
          <span className="mt-1 block text-xs text-gray-500">{valuePrefix}{minValue}{valueSuffix} (Min)</span>
        </div>
        <div className="w-1/2">
          <input
            type="number"
            value={maxValue}
            onChange={handleMaxChange}
            min={min}
            max={max}
            step={step}
            className="w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500 sm:text-sm"
          />
          <span className="mt-1 block text-xs text-gray-500">{valuePrefix}{maxValue}{valueSuffix} (Max)</span>
        </div>
      </div>
    </div>
  );
};

interface MultiSelectFilterProps {
  label: string;
  options: string[];
  selected: string[];
  onChange: (selected: string[]) => void;
}

const MultiSelectFilter: React.FC<MultiSelectFilterProps> = ({
  label,
  options,
  selected,
  onChange,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredOptions = options.filter(option => 
    option.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const toggleOption = (option: string) => {
    if (selected.includes(option)) {
      onChange(selected.filter(item => item !== option));
    } else {
      onChange([...selected, option]);
    }
  };

  return (
    <div className="mb-4 relative">
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      <div 
        className="flex items-center justify-between w-full cursor-pointer rounded-md border border-gray-300 bg-white px-3 py-2 shadow-sm focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500"
        onClick={() => setIsOpen(!isOpen)}
      >
        <div className="flex flex-wrap gap-1">
          {selected.length === 0 ? (
            <span className="text-gray-500">Select {label}</span>
          ) : (
            selected.map(item => (
              <span 
                key={item} 
                className="inline-flex items-center rounded-full bg-purple-100 px-2.5 py-0.5 text-xs font-medium text-purple-800"
              >
                {item}
                <button
                  type="button"
                  className="ml-1 inline-flex h-4 w-4 flex-shrink-0 items-center justify-center rounded-full text-purple-400 hover:bg-purple-200 hover:text-purple-500 focus:bg-purple-500 focus:text-white focus:outline-none"
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleOption(item);
                  }}
                >
                  <X className="h-3 w-3" />
                </button>
              </span>
            ))
          )}
        </div>
        {isOpen ? <ChevronUp className="h-5 w-5 text-gray-400" /> : <ChevronDown className="h-5 w-5 text-gray-400" />}
      </div>
      
      {isOpen && (
        <div className="absolute z-10 mt-1 w-full rounded-md bg-white shadow-lg">
          <div className="p-2 border-b">
            <div className="relative">
              <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                <Search className="h-4 w-4 text-gray-400" />
              </div>
              <input
                type="text"
                className="block w-full rounded-md border-0 py-1.5 pl-10 text-gray-900 ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-purple-600 sm:text-sm sm:leading-6"
                placeholder="Search..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onClick={(e) => e.stopPropagation()}
              />
            </div>
          </div>
          <ul className="max-h-60 overflow-auto py-1 text-base">
            {filteredOptions.map((option) => (
              <li
                key={option}
                className={`relative cursor-pointer select-none py-2 pl-3 pr-9 ${
                  selected.includes(option) ? 'bg-purple-100 text-purple-900' : 'text-gray-900 hover:bg-gray-100'
                }`}
                onClick={(e) => {
                  e.stopPropagation();
                  toggleOption(option);
                }}
              >
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    checked={selected.includes(option)}
                    onChange={() => {}}
                    className="h-4 w-4 rounded border-gray-300 text-purple-600 focus:ring-purple-500"
                  />
                  <span className="ml-3 block truncate">{option}</span>
                </div>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

interface DateRangeFilterProps {
  label: string;
  onChange: (startDate: string, endDate: string) => void;
}

const DateRangeFilter: React.FC<DateRangeFilterProps> = ({ label, onChange }) => {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const handleStartDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setStartDate(e.target.value);
    onChange(e.target.value, endDate);
  };

  const handleEndDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEndDate(e.target.value);
    onChange(startDate, e.target.value);
  };

  return (
    <div className="mb-4">
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      <div className="flex items-center space-x-2">
        <div className="w-1/2">
          <input
            type="date"
            value={startDate}
            onChange={handleStartDateChange}
            className="w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500 sm:text-sm"
          />
          <span className="mt-1 block text-xs text-gray-500">Start Date</span>
        </div>
        <div className="w-1/2">
          <input
            type="date"
            value={endDate}
            onChange={handleEndDateChange}
            className="w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500 sm:text-sm"
          />
          <span className="mt-1 block text-xs text-gray-500">End Date</span>
        </div>
      </div>
    </div>
  );
};

interface TextFilterProps {
  label: string;
  placeholder?: string;
  onChange: (value: string) => void;
}

const TextFilter: React.FC<TextFilterProps> = ({ label, placeholder, onChange }) => {
  return (
    <div className="mb-4">
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      <input
        type="text"
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500 sm:text-sm"
      />
    </div>
  );
};

interface FilterPanelProps {
  onApplyFilters: (filters: any) => void;
}

const FilterPanel: React.FC<FilterPanelProps> = ({ onApplyFilters }) => {
  const [filters, setFilters] = useState({
    location: [],
    niche: [],
    platforms: [],
    followers: { min: 0, max: 1000000 },
    avgViews: { min: 0, max: 500000 },
    productSales: { min: 0, max: 10000 },
    productPrice: { min: 0, max: 10000 },
    engagementRate: { min: 0, max: 100 },
    productRating: { min: 0, max: 5 },
    endorsementDate: { start: '', end: '' },
    hashtags: '',
    languages: '',
  });

  const [sections, setSections] = useState({
    basic: true,
    metrics: true,
    products: true,
    additional: true,
  });

  const toggleSection = (section: keyof typeof sections) => {
    setSections({
      ...sections,
      [section]: !sections[section],
    });
  };

  const handleApplyFilters = () => {
    onApplyFilters(filters);
  };

  const handleClearFilters = () => {
    setFilters({
      location: [],
      niche: [],
      platforms: [],
      followers: { min: 0, max: 1000000 },
      avgViews: { min: 0, max: 500000 },
      productSales: { min: 0, max: 10000 },
      productPrice: { min: 0, max: 10000 },
      engagementRate: { min: 0, max: 100 },
      productRating: { min: 0, max: 5 },
      endorsementDate: { start: '', end: '' },
      hashtags: '',
      languages: '',
    });
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-medium text-gray-900">Filter Creators</h2>
        <button
          onClick={handleClearFilters}
          className="text-sm text-purple-600 hover:text-purple-800"
        >
          Clear All
        </button>
      </div>

      {/* Basic Filters */}
      <div className="border-b border-gray-200 pb-4 mb-4">
        <button
          className="flex w-full items-center justify-between text-left"
          onClick={() => toggleSection('basic')}
        >
          <h3 className="text-md font-medium text-gray-900">Basic Filters</h3>
          {sections.basic ? (
            <ChevronUp className="h-5 w-5 text-gray-500" />
          ) : (
            <ChevronDown className="h-5 w-5 text-gray-500" />
          )}
        </button>
        
        {sections.basic && (
          <div className="mt-4">
            <MultiSelectFilter
              label="Platforms"
              options={['Instagram', 'TikTok', 'YouTube', 'Twitter', 'LinkedIn', 'Facebook']}
              selected={filters.platforms}
              onChange={(selected) => setFilters({ ...filters, platforms: selected })}
            />
            
            <MultiSelectFilter
              label="Niche"
              options={['Fashion', 'Beauty', 'Fitness', 'Travel', 'Food', 'Technology', 'Lifestyle', 'Gaming', 'Business', 'Education']}
              selected={filters.niche}
              onChange={(selected) => setFilters({ ...filters, niche: selected })}
            />
            
            <MultiSelectFilter
              label="Location"
              options={['Mumbai', 'Delhi', 'Bangalore', 'Chennai', 'Hyderabad', 'Kolkata', 'Pune', 'Ahmedabad', 'Jaipur', 'Surat']}
              selected={filters.location}
              onChange={(selected) => setFilters({ ...filters, location: selected })}
            />
          </div>
        )}
      </div>

      {/* Metric Filters */}
      <div className="border-b border-gray-200 pb-4 mb-4">
        <button
          className="flex w-full items-center justify-between text-left"
          onClick={() => toggleSection('metrics')}
        >
          <h3 className="text-md font-medium text-gray-900">Audience Metrics</h3>
          {sections.metrics ? (
            <ChevronUp className="h-5 w-5 text-gray-500" />
          ) : (
            <ChevronDown className="h-5 w-5 text-gray-500" />
          )}
        </button>
        
        {sections.metrics && (
          <div className="mt-4">
            <RangeFilter
              label="Followers"
              min={0}
              max={1000000}
              step={1000}
              valueSuffix="K"
              onChange={(min, max) => setFilters({ ...filters, followers: { min, max } })}
            />
            
            <RangeFilter
              label="Average Views"
              min={0}
              max={500000}
              step={1000}
              onChange={(min, max) => setFilters({ ...filters, avgViews: { min, max } })}
            />
            
            <RangeFilter
              label="Engagement Rate"
              min={0}
              max={100}
              step={0.1}
              valueSuffix="%"
              onChange={(min, max) => setFilters({ ...filters, engagementRate: { min, max } })}
            />
          </div>
        )}
      </div>

      {/* Product Filters */}
      <div className="border-b border-gray-200 pb-4 mb-4">
        <button
          className="flex w-full items-center justify-between text-left"
          onClick={() => toggleSection('products')}
        >
          <h3 className="text-md font-medium text-gray-900">Product Metrics</h3>
          {sections.products ? (
            <ChevronUp className="h-5 w-5 text-gray-500" />
          ) : (
            <ChevronDown className="h-5 w-5 text-gray-500" />
          )}
        </button>
        
        {sections.products && (
          <div className="mt-4">
            <RangeFilter
              label="Product Sales"
              min={0}
              max={10000}
              valuePrefix="₹"
              onChange={(min, max) => setFilters({ ...filters, productSales: { min, max } })}
            />
            
            <RangeFilter
              label="Product Price"
              min={0}
              max={10000}
              valuePrefix="₹"
              onChange={(min, max) => setFilters({ ...filters, productPrice: { min, max } })}
            />
            
            <RangeFilter
              label="Product Rating"
              min={0}
              max={5}
              step={0.1}
              onChange={(min, max) => setFilters({ ...filters, productRating: { min, max } })}
            />
          </div>
        )}
      </div>

      {/* Additional Filters */}
      <div className="pb-4 mb-4">
        <button
          className="flex w-full items-center justify-between text-left"
          onClick={() => toggleSection('additional')}
        >
          <h3 className="text-md font-medium text-gray-900">Additional Filters</h3>
          {sections.additional ? (
            <ChevronUp className="h-5 w-5 text-gray-500" />
          ) : (
            <ChevronDown className="h-5 w-5 text-gray-500" />
          )}
        </button>
        
        {sections.additional && (
          <div className="mt-4">
            <DateRangeFilter
              label="Endorsement Date"
              onChange={(start, end) => 
                setFilters({ ...filters, endorsementDate: { start, end } })
              }
            />
            
            <TextFilter
              label="Hashtags"
              placeholder="#fashion #beauty"
              onChange={(value) => setFilters({ ...filters, hashtags: value })}
            />
            
            <TextFilter
              label="Languages"
              placeholder="English, Hindi"
              onChange={(value) => setFilters({ ...filters, languages: value })}
            />
          </div>
        )}
      </div>

      <button
        onClick={handleApplyFilters}
        className="w-full rounded-md bg-purple-600 py-2 px-4 text-white font-medium hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 transition-colors duration-200"
      >
        Apply Filters
      </button>
    </div>
  );
};

export default FilterPanel;