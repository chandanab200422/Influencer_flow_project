import React from 'react';
import { Instagram, Youtube, Twitter, Heart, Eye, DollarSign, Star } from 'lucide-react';

export interface Creator {
  id: string;
  name: string;
  username: string;
  image: string;
  location: string;
  niche: string[];
  platforms: string[];
  followers: number;
  engagementRate: number;
  avgViews: number;
  productSales: number;
  productRating: number;
  bio: string;
  bestProduct: string;
  productCategory: string;
  productPrice: number;
  productImage: string;
  endorsementType: string;
  endorsementDate: string;
  languages: string[];
  hashtags: string[];
}

interface CreatorCardProps {
  creator: Creator;
  onClick: (creator: Creator) => void;
}

const CreatorCard: React.FC<CreatorCardProps> = ({ creator, onClick }) => {
  const getPlatformIcon = (platform: string) => {
    switch (platform.toLowerCase()) {
      case 'instagram':
        return <Instagram className="h-4 w-4" />;
      case 'youtube':
        return <Youtube className="h-4 w-4" />;
      case 'twitter':
        return <Twitter className="h-4 w-4" />;
      default:
        return <Instagram className="h-4 w-4" />;
    }
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    }
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  };

  return (
    <div 
      className="overflow-hidden rounded-lg bg-white shadow transition-all duration-300 hover:shadow-md cursor-pointer"
      onClick={() => onClick(creator)}
    >
      <div className="h-40 w-full bg-gray-200 overflow-hidden">
        <img 
  src={`https://robohash.org/${creator.username}?set=set4=${encodeURIComponent(creator.name)}`} 
  alt={creator.name}
  className="h-full w-full object-cover object-center"
/>

      </div>
      
      <div className="p-5">
        <div className="flex justify-between items-start mb-3">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 truncate">{creator.name}</h3>
            <p className="text-sm text-gray-500">{creator.username}</p>
            <p className="text-sm text-gray-500">{creator.location}</p>
          </div>
          <div className="flex space-x-1">
            {creator.platforms.map((platform, index) => (
              <span 
                key={index}
                className="inline-flex items-center rounded-full bg-purple-100 p-1.5"
              >
                {getPlatformIcon(platform)}
              </span>
            ))}
          </div>
        </div>
        
        <div className="mb-3">
          <div className="flex flex-wrap gap-1 mb-2">
            {creator.niche.map((tag, index) => (
              <span 
                key={index}
                className="inline-flex items-center rounded-full bg-gray-100 px-2.5 py-0.5 text-xs font-medium text-gray-800"
              >
                {tag}
              </span>
            ))}
          </div>
          
          <p className="text-sm text-gray-600 line-clamp-2">{creator.bio}</p>
        </div>
        
        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="rounded-md bg-gray-50 p-2">
            <div className="flex items-center justify-center text-purple-600 mb-1">
              <Eye className="h-4 w-4 mr-1" />
            </div>
            <p className="text-xs font-medium text-gray-900">{formatNumber(creator.followers)}</p>
            <p className="text-xs text-gray-500">Followers</p>
          </div>
          
          <div className="rounded-md bg-gray-50 p-2">
            <div className="flex items-center justify-center text-purple-600 mb-1">
              <Heart className="h-4 w-4 mr-1" />
            </div>
            <p className="text-xs font-medium text-gray-900">{creator.engagementRate.toFixed(1)}%</p>
            <p className="text-xs text-gray-500">Engagement</p>
          </div>
          
          <div className="rounded-md bg-gray-50 p-2">
            <div className="flex items-center justify-center text-purple-600 mb-1">
              {creator.productRating ? (
                <Star className="h-4 w-4 mr-1" />
              ) : (
                <DollarSign className="h-4 w-4 mr-1" />
              )}
            </div>
            <p className="text-xs font-medium text-gray-900">
              {creator.productRating ? 
                creator.productRating.toFixed(1) : 
                formatNumber(creator.avgViews)
              }
            </p>
            <p className="text-xs text-gray-500">
              {creator.productRating ? 'Rating' : 'Avg. Views'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreatorCard;