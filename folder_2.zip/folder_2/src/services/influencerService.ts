import { Creator } from '../components/CreatorCard';

// Parse string values that may contain arrays
const parseArrayString = (str: string): string[] => {
  try {
    return JSON.parse(str.replace(/\{|\}/g, '["').replace(/,/g, '","') + '"]');
  } catch {
    return [];
  }
};

// Convert price string to number
const parsePrice = (price: string): number => {
  return Number(price.replace('₹', '').replace(',', ''));
};

// Convert Lakh format to number
const parseLakhValue = (value: string): number => {
  if (value.endsWith('L')) {
    return Number(value.replace('L', '')) * 100000;
  }
  return Number(value);
};

export const getCreators = async (filters: any = {}): Promise<Creator[]> => {
  try {
    const response = await fetch('/data/influencers.csv');
    const text = await response.text();
    const rows = text.split('\n').slice(1); // Skip header row

    let creators: Creator[] = rows.map(row => {
      const columns = row.split(',');
      if (columns.length < 22) return null;

      const [
        id, name, username, bio, location, niche, followers, engagementRate,
        avgViews, avgLikes, avgComments, bestProduct, productSales, productCategory,
        productRating, productPrice, productImage, endorsementType, endorsementDate,
        languages, profilePic, platforms, hashtags
      ] = columns;

      return {
        id,
        name: name.trim(),
        image: profilePic.replace(/"/g, ''),
        location: location.replace(/"/g, ''),
        niche: parseArrayString(niche),
        platforms: parseArrayString(platforms),
        followers: Number(followers),
        engagementRate: Number(engagementRate),
        avgViews: Number(avgViews),
        productSales: parseLakhValue(productSales.replace(/"/g, '')),
        productRating: Number(productRating),
        bio: bio.replace(/"/g, ''),
        username: username,
        bestProduct: bestProduct.replace(/"/g, ''),
        productCategory: productCategory.replace(/"/g, ''),
        productPrice: parsePrice(productPrice),
        productImage: productImage.replace(/"/g, ''),
        endorsementType: endorsementType.replace(/"/g, ''),
        endorsementDate: endorsementDate.replace(/"/g, ''),
        languages: parseArrayString(languages),
        hashtags: parseArrayString(hashtags)
      };
    }).filter(creator => creator !== null) as Creator[];

    // Apply filters
    if (filters) {
      if (filters.location?.length) {
        creators = creators.filter(creator => 
          filters.location.some((loc: string) => creator.location.toLowerCase().includes(loc.toLowerCase()))
        );
      }

      if (filters.niche?.length) {
        creators = creators.filter(creator =>
          filters.niche.some((n: string) => creator.niche.some(cn => cn.toLowerCase().includes(n.toLowerCase())))
        );
      }

      if (filters.platforms?.length) {
        creators = creators.filter(creator =>
          filters.platforms.some((p: string) => creator.platforms.includes(p))
        );
      }

      if (filters.followers?.min !== undefined) {
        creators = creators.filter(creator => creator.followers >= filters.followers.min);
      }
      if (filters.followers?.max !== undefined) {
        creators = creators.filter(creator => creator.followers <= filters.followers.max);
      }

      if (filters.avgViews?.min !== undefined) {
        creators = creators.filter(creator => creator.avgViews >= filters.avgViews.min);
      }
      if (filters.avgViews?.max !== undefined) {
        creators = creators.filter(creator => creator.avgViews <= filters.avgViews.max);
      }

      if (filters.productSales?.min !== undefined) {
        creators = creators.filter(creator => creator.productSales >= filters.productSales.min);
      }
      if (filters.productSales?.max !== undefined) {
        creators = creators.filter(creator => creator.productSales <= filters.productSales.max);
      }

      if (filters.engagementRate?.min !== undefined) {
        creators = creators.filter(creator => creator.engagementRate >= filters.engagementRate.min);
      }
      if (filters.engagementRate?.max !== undefined) {
        creators = creators.filter(creator => creator.engagementRate <= filters.engagementRate.max);
      }

      if (filters.productRating?.min !== undefined) {
        creators = creators.filter(creator => creator.productRating >= filters.productRating.min);
      }
      if (filters.productRating?.max !== undefined) {
        creators = creators.filter(creator => creator.productRating <= filters.productRating.max);
      }

      if (filters.endorsementDate?.start) {
        creators = creators.filter(creator => 
          new Date(creator.endorsementDate) >= new Date(filters.endorsementDate.start)
        );
      }
      if (filters.endorsementDate?.end) {
        creators = creators.filter(creator => 
          new Date(creator.endorsementDate) <= new Date(filters.endorsementDate.end)
        );
      }

      if (filters.hashtags) {
        creators = creators.filter(creator =>
          creator.hashtags.some(tag => tag.toLowerCase().includes(filters.hashtags.toLowerCase()))
        );
      }

      if (filters.languages) {
        creators = creators.filter(creator =>
          creator.languages.some(lang => lang.toLowerCase().includes(filters.languages.toLowerCase()))
        );
      }
    }

    return creators;
  } catch (error) {
    console.error('Error loading creators:', error);
    return [];
  }
};