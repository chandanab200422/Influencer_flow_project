import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Instagram, Youtube, Twitter, Globe, Mail, MapPin, Briefcase, Tag, ArrowLeft, Star, BarChart, DollarSign, Heart, Eye, Users, Calendar, Award, TrendingUp, MessageCircle } from 'lucide-react';
import { Creator } from '../components/CreatorCard';
import { getCreators } from '../services/influencerService';

const CreatorProfile: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [creator, setCreator] = React.useState<Creator | null>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const loadCreator = async () => {
      const creators = await getCreators();
      const found = creators.find(c => c.id === id);
      setCreator(found || null);
      setLoading(false);
    };
    loadCreator();
  }, [id]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  if (!creator) {
    return (
      <div className="text-center py-10">
        <p className="text-lg text-gray-600">Creator not found</p>
        <button 
          onClick={() => navigate('/creators')}
          className="mt-4 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Creators
        </button>
      </div>
    );
  }

  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    }
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  };

  const getPlatformIcon = (platform: string) => {
    switch (platform.toLowerCase()) {
      case 'instagram':
        return <Instagram className="h-5 w-5" />;
      case 'youtube':
        return <Youtube className="h-5 w-5" />;
      case 'twitter':
        return <Twitter className="h-5 w-5" />;
      default:
        return <Globe className="h-5 w-5" />;
    }
  };

  const getPlatformColor = (platform: string) => {
    switch (platform.toLowerCase()) {
      case 'instagram':
        return 'bg-gradient-to-r from-purple-500 to-pink-500';
      case 'youtube':
        return 'bg-gradient-to-r from-red-500 to-red-600';
      case 'twitter':
        return 'bg-gradient-to-r from-blue-400 to-blue-500';
      default:
        return 'bg-gradient-to-r from-gray-500 to-gray-600';
    }
  };

  return (
    <div>
      <button 
        onClick={() => navigate('/creators')}
        className="mb-6 inline-flex items-center text-purple-600 hover:text-purple-800"
      >
        <ArrowLeft className="h-4 w-4 mr-1" />
        Back to Creators
      </button>

      <div className="bg-white rounded-lg shadow-lg overflow-hidden">
        {/* Header section */}
        <div className="relative h-64">
          <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-indigo-600 opacity-90"></div>
          <div className="absolute inset-0 bg-[url('')] bg-cover bg-center mix-blend-overlay"></div>
          <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
            <div className="flex items-end space-x-6">
              <div className="h-32 w-32 rounded-xl overflow-hidden border-4 border-white shadow-lg">
                <img
                  src={creator.image}
                  alt={creator.name}
                  className="h-full w-full object-cover"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = 'https://robohash.org/${creator.username}?set=set4=${encodeURIComponent(creator.name)}';
                  }}
                />
              </div>
              <div className="flex-1 pb-2">
                <h1 className="text-3xl font-bold">{creator.name}</h1>
                <p className="text-lg opacity-90">{creator.username}</p>
                <div className="flex items-center mt-2 text-sm">
                  <MapPin className="h-4 w-4 mr-1" />
                  <span>{creator.location}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Main content */}
        <div className="p-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left column */}
            <div className="lg:col-span-2">
              {/* Bio section */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 mb-6">
                <h2 className="text-xl font-semibold mb-4">About</h2>
                <p className="text-gray-600 leading-relaxed">{creator.bio}</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {creator.hashtags.map((tag, index) => (
                    <span
                      key={index}
                      className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-purple-100 text-purple-800"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* Platform stats */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                {creator.platforms.map((platform, index) => (
                  <div
                    key={index}
                    className={`rounded-xl p-6 text-white ${getPlatformColor(platform)}`}
                  >
                    <div className="flex items-center justify-between mb-4">
                      {getPlatformIcon(platform)}
                      <span className="text-sm font-medium">{platform}</span>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span>Followers</span>
                        <span className="font-bold">{formatNumber(creator.followers)}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Avg. Views</span>
                        <span className="font-bold">{formatNumber(creator.avgViews)}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Engagement</span>
                        <span className="font-bold">{creator.engagementRate.toFixed(1)}%</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Performance metrics */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 mb-6">
                <h2 className="text-xl font-semibold mb-4 flex items-center">
                  <Award className="h-5 w-5 mr-2 text-purple-600" />
                  Performance Highlights
                </h2>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="p-4 rounded-lg bg-purple-50 text-center">
                    <TrendingUp className="h-6 w-6 text-purple-600 mx-auto mb-2" />
                    <div className="text-2xl font-bold text-purple-700">{formatNumber(creator.avgViews)}</div>
                    <div className="text-sm text-purple-600">Average Views</div>
                  </div>
                  <div className="p-4 rounded-lg bg-blue-50 text-center">
                    <MessageCircle className="h-6 w-6 text-blue-600 mx-auto mb-2" />
                    <div className="text-2xl font-bold text-blue-700">{creator.engagementRate.toFixed(1)}%</div>
                    <div className="text-sm text-blue-600">Engagement Rate</div>
                  </div>
                  <div className="p-4 rounded-lg bg-green-50 text-center">
                    <DollarSign className="h-6 w-6 text-green-600 mx-auto mb-2" />
                    <div className="text-2xl font-bold text-green-700">{formatNumber(creator.productSales)}</div>
                    <div className="text-sm text-green-600">Product Sales</div>
                  </div>
                  <div className="p-4 rounded-lg bg-yellow-50 text-center">
                    <Star className="h-6 w-6 text-yellow-600 mx-auto mb-2" />
                    <div className="text-2xl font-bold text-yellow-700">{creator.productRating.toFixed(1)}</div>
                    <div className="text-sm text-yellow-600">Product Rating</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Right column */}
            <div>
              {/* Quick actions */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 mb-6">
                <button className="w-full bg-purple-600 text-white rounded-lg py-3 font-medium hover:bg-purple-700 transition-colors mb-3">
                  Contact Creator
                </button>
                <button className="w-full bg-white text-purple-600 border border-purple-600 rounded-lg py-3 font-medium hover:bg-purple-50 transition-colors">
                  Save Profile
                </button>
              </div>

              {/* Creator details */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 mb-6">
                <h3 className="font-semibold text-gray-900 mb-4">Creator Details</h3>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm text-gray-500">Languages</label>
                    <div className="mt-1 flex flex-wrap gap-2">
                      {creator.languages.map((language, index) => (
                        <span
                          key={index}
                          className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800"
                        >
                          {language}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="text-sm text-gray-500">Niche</label>
                    <div className="mt-1 flex flex-wrap gap-2">
                      {creator.niche.map((n, index) => (
                        <span
                          key={index}
                          className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800"
                        >
                          {n}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="text-sm text-gray-500">Best Performing Product</label>
                    <div className="mt-2 p-3 rounded-lg bg-gray-50">
                      <div className="flex items-center space-x-3">
                        <div className="h-16 w-16 flex-shrink-0">
                          <img
                            src={creator.productImage}
                            alt={creator.bestProduct}
                            className="h-full w-full object-cover rounded-lg"
                          />
                        </div>
                        <div>
                          <h4 className="font-medium text-sm">{creator.bestProduct}</h4>
                          <p className="text-sm text-gray-500">{creator.productCategory}</p>
                          <p className="text-sm font-medium text-purple-600">₹{creator.productPrice.toLocaleString()}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Recent activity */}
              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
                <h3 className="font-semibold text-gray-900 mb-4">Recent Activity</h3>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <div className="flex-shrink-0">
                      <Calendar className="h-5 w-5 text-gray-400" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-900">Latest Endorsement</p>
                      <p className="text-sm text-gray-500">{creator.endorsementType} • {creator.endorsementDate}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreatorProfile;