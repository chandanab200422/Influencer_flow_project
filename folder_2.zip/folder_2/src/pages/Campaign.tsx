import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Send, FileText, DollarSign, Check } from 'lucide-react';

// Campaign steps
const CAMPAIGN_STEPS = [
  { id: 'product', name: 'Product Details' },
  { id: 'creators', name: 'Select Creators' },
  { id: 'message', name: 'Compose Message' },
  { id: 'payment', name: 'Payment' },
];

const Campaign: React.FC = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(0);
  const [campaignData, setCampaignData] = useState({
    productName: '',
    productDescription: '',
    productCategory: '',
    budget: '',
    selectedCreators: [] as string[],
    message: '',
    paymentMethod: '',
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setCampaignData({
      ...campaignData,
      [name]: value,
    });
  };

  const handleNextStep = () => {
    setCurrentStep(currentStep + 1);
  };

  const handlePrevStep = () => {
    setCurrentStep(currentStep - 1);
  };

  // Sample creators for the selection step
  const sampleCreators = [
    { id: '1', name: 'Priya Sharma', platform: 'Instagram', followers: '230K', image: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=150' },
    { id: '2', name: 'Rahul Patel', platform: 'YouTube', followers: '500K', image: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=150' },
    { id: '3', name: 'Ananya Desai', platform: 'Instagram', followers: '125K', image: 'https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg?auto=compress&cs=tinysrgb&w=150' },
  ];

  const toggleCreatorSelection = (creatorId: string) => {
    const selectedCreators = [...campaignData.selectedCreators];
    
    if (selectedCreators.includes(creatorId)) {
      setCampaignData({
        ...campaignData,
        selectedCreators: selectedCreators.filter(id => id !== creatorId),
      });
    } else {
      setCampaignData({
        ...campaignData,
        selectedCreators: [...selectedCreators, creatorId],
      });
    }
  };

  const renderStep = () => {
    switch (CAMPAIGN_STEPS[currentStep].id) {
      case 'product':
        return (
          <div>
            <h2 className="text-lg font-medium text-gray-900 mb-6">Tell us about your product</h2>
            
            <div className="space-y-4">
              <div>
                <label htmlFor="productName" className="block text-sm font-medium text-gray-700 mb-1">
                  Product Name
                </label>
                <input
                  type="text"
                  id="productName"
                  name="productName"
                  value={campaignData.productName}
                  onChange={handleInputChange}
                  className="w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                  placeholder="e.g., Eco-Friendly Water Bottle"
                />
              </div>
              
              <div>
                <label htmlFor="productCategory" className="block text-sm font-medium text-gray-700 mb-1">
                  Product Category
                </label>
                <select
                  id="productCategory"
                  name="productCategory"
                  value={campaignData.productCategory}
                  onChange={handleInputChange}
                  className="w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                >
                  <option value="">Select a category</option>
                  <option value="eco-products">Eco-Friendly Products</option>
                  <option value="fashion">Fashion & Apparel</option>
                  <option value="beauty">Beauty & Personal Care</option>
                  <option value="food">Food & Beverages</option>
                  <option value="health">Health & Wellness</option>
                  <option value="tech">Tech & Gadgets</option>
                </select>
              </div>
              
              <div>
                <label htmlFor="productDescription" className="block text-sm font-medium text-gray-700 mb-1">
                  Product Description
                </label>
                <textarea
                  id="productDescription"
                  name="productDescription"
                  value={campaignData.productDescription}
                  onChange={handleInputChange}
                  rows={4}
                  className="w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                  placeholder="Describe your product, its features, and why it's special..."
                />
              </div>
              
              <div>
                <label htmlFor="budget" className="block text-sm font-medium text-gray-700 mb-1">
                  Campaign Budget (₹)
                </label>
                <input
                  type="number"
                  id="budget"
                  name="budget"
                  value={campaignData.budget}
                  onChange={handleInputChange}
                  className="w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                  placeholder="e.g., 5000"
                />
              </div>
            </div>
          </div>
        );
        
      case 'creators':
        return (
          <div>
            <h2 className="text-lg font-medium text-gray-900 mb-6">Select creators for your campaign</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              {sampleCreators.map((creator) => (
                <div 
                  key={creator.id}
                  className={`flex items-center p-4 border rounded-lg cursor-pointer transition-colors ${
                    campaignData.selectedCreators.includes(creator.id)
                      ? 'border-purple-500 bg-purple-50'
                      : 'border-gray-200 hover:bg-gray-50'
                  }`}
                  onClick={() => toggleCreatorSelection(creator.id)}
                >
                  <div className="relative mr-3 flex-shrink-0">
                    <img
                      src={creator.image}
                      alt={creator.name}
                      className="h-12 w-12 rounded-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = 'https://images.pexels.com/photos/1438081/pexels-photo-1438081.jpeg?auto=compress&cs=tinysrgb&w=150';
                      }}
                    />
                    {campaignData.selectedCreators.includes(creator.id) && (
                      <div className="absolute -bottom-1 -right-1 h-5 w-5 rounded-full bg-purple-500 flex items-center justify-center">
                        <Check className="h-3 w-3 text-white" />
                      </div>
                    )}
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{creator.name}</p>
                    <p className="text-sm text-gray-500">{creator.platform} • {creator.followers} followers</p>
                  </div>
                </div>
              ))}
            </div>
            
            <p className="text-sm text-gray-500">
              Selected {campaignData.selectedCreators.length} creators
            </p>
          </div>
        );
        
      case 'message':
        return (
          <div>
            <h2 className="text-lg font-medium text-gray-900 mb-6">Compose your outreach message</h2>
            
            <div className="bg-white border border-gray-200 rounded-lg p-4 mb-6">
              <div className="flex items-center mb-4">
                <span className="inline-flex items-center justify-center h-8 w-8 rounded-full bg-purple-100 text-purple-500 mr-2">
                  <Send className="h-4 w-4" />
                </span>
                <span className="font-medium">Email Draft</span>
              </div>
              
              <textarea
                name="message"
                value={campaignData.message || `Hi there,

I'm [Your Name] from [Your Company]. We're launching our ${campaignData.productName || '[Product Name]'} and we'd love to collaborate with you on a promotion.

${campaignData.productDescription || '[Your product description will appear here]'}

Our budget for this campaign is ₹${campaignData.budget || '[Budget]'}. Would you be interested in promoting our product?

Looking forward to your response!

Best regards,
[Your Name]
[Your Company]`}
                onChange={handleInputChange}
                rows={12}
                className="w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
              />
              
              <p className="mt-2 text-sm text-gray-500">
                This message will be sent to {campaignData.selectedCreators.length} selected creators.
              </p>
            </div>
          </div>
        );
        
      case 'payment':
        return (
          <div>
            <h2 className="text-lg font-medium text-gray-900 mb-6">Payment details</h2>
            
            <div className="bg-white border border-gray-200 rounded-lg p-4 mb-6">
              <div className="flex items-center mb-4">
                <span className="inline-flex items-center justify-center h-8 w-8 rounded-full bg-purple-100 text-purple-500 mr-2">
                  <FileText className="h-4 w-4" />
                </span>
                <span className="font-medium">Campaign Summary</span>
              </div>
              
              <div className="space-y-2 mb-4">
                <div className="flex justify-between py-2 border-b border-gray-100">
                  <span className="text-gray-600">Product:</span>
                  <span className="font-medium">{campaignData.productName || 'Not specified'}</span>
                </div>
                <div className="flex justify-between py-2 border-b border-gray-100">
                  <span className="text-gray-600">Category:</span>
                  <span className="font-medium">{campaignData.productCategory || 'Not specified'}</span>
                </div>
                <div className="flex justify-between py-2 border-b border-gray-100">
                  <span className="text-gray-600">Creators selected:</span>
                  <span className="font-medium">{campaignData.selectedCreators.length}</span>
                </div>
                <div className="flex justify-between py-2 border-b border-gray-100">
                  <span className="text-gray-600">Campaign budget:</span>
                  <span className="font-medium">₹{campaignData.budget || '0'}</span>
                </div>
              </div>
            </div>
            
            <div className="bg-white border border-gray-200 rounded-lg p-4 mb-6">
              <div className="flex items-center mb-4">
                <span className="inline-flex items-center justify-center h-8 w-8 rounded-full bg-purple-100 text-purple-500 mr-2">
                  <DollarSign className="h-4 w-4" />
                </span>
                <span className="font-medium">Payment Method</span>
              </div>
              
              <div className="space-y-2">
                <label className="flex items-center p-3 border border-gray-200 rounded-md cursor-pointer hover:bg-gray-50">
                  <input
                    type="radio"
                    name="paymentMethod"
                    value="credit_card"
                    checked={campaignData.paymentMethod === 'credit_card'}
                    onChange={handleInputChange}
                    className="h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300"
                  />
                  <span className="ml-2">Credit Card</span>
                </label>
                
                <label className="flex items-center p-3 border border-gray-200 rounded-md cursor-pointer hover:bg-gray-50">
                  <input
                    type="radio"
                    name="paymentMethod"
                    value="upi"
                    checked={campaignData.paymentMethod === 'upi'}
                    onChange={handleInputChange}
                    className="h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300"
                  />
                  <span className="ml-2">UPI</span>
                </label>
                
                <label className="flex items-center p-3 border border-gray-200 rounded-md cursor-pointer hover:bg-gray-50">
                  <input
                    type="radio"
                    name="paymentMethod"
                    value="bank_transfer"
                    checked={campaignData.paymentMethod === 'bank_transfer'}
                    onChange={handleInputChange}
                    className="h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300"
                  />
                  <span className="ml-2">Bank Transfer</span>
                </label>
              </div>
            </div>
          </div>
        );
        
      default:
        return null;
    }
  };

  return (
    <div>
      <button 
        onClick={() => navigate('/creators')}
        className="mb-6 inline-flex items-center text-purple-600 hover:text-purple-800"
      >
        <ArrowLeft className="h-4 w-4 mr-1" />
        Back to Creators
      </button>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="border-b border-gray-200">
          <div className="px-6 py-4">
            <h1 className="text-xl font-semibold text-gray-900">Create Campaign</h1>
            <p className="text-sm text-gray-500">Set up your influencer marketing campaign</p>
          </div>
          
          {/* Steps indicator */}
          <div className="px-6 py-3 bg-gray-50">
            <nav className="flex items-center">
              {CAMPAIGN_STEPS.map((step, index) => (
                <React.Fragment key={step.id}>
                  {/* Step */}
                  <div className="flex items-center">
                    <div
                      className={`flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full ${
                        index < currentStep
                          ? 'bg-purple-600'
                          : index === currentStep
                          ? 'border-2 border-purple-600 bg-white'
                          : 'border-2 border-gray-300 bg-white'
                      }`}
                    >
                      <span
                        className={`text-sm font-medium ${
                          index < currentStep
                            ? 'text-white'
                            : index === currentStep
                            ? 'text-purple-600'
                            : 'text-gray-500'
                        }`}
                      >
                        {index + 1}
                      </span>
                    </div>
                    <span
                      className={`ml-2 text-sm font-medium ${
                        index <= currentStep ? 'text-gray-900' : 'text-gray-500'
                      }`}
                    >
                      {step.name}
                    </span>
                  </div>
                  
                  {/* Connector */}
                  {index < CAMPAIGN_STEPS.length - 1 && (
                    <div className="flex-1 mx-4">
                      <div
                        className={`h-0.5 ${
                          index < currentStep ? 'bg-purple-600' : 'bg-gray-300'
                        }`}
                      ></div>
                    </div>
                  )}
                </React.Fragment>
              ))}
            </nav>
          </div>
        </div>
        
        {/* Step content */}
        <div className="p-6">
          {renderStep()}
          
          {/* Navigation buttons */}
          <div className="mt-8 flex justify-between">
            <button
              type="button"
              onClick={handlePrevStep}
              disabled={currentStep === 0}
              className={`inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium ${
                currentStep === 0
                  ? 'text-gray-400 bg-gray-100 cursor-not-allowed'
                  : 'text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500'
              }`}
            >
              Previous
            </button>
            
            <button
              type="button"
              onClick={handleNextStep}
              className={`inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 ${
                currentStep === CAMPAIGN_STEPS.length - 1 ? 'cursor-pointer' : ''
              }`}
            >
              {currentStep === CAMPAIGN_STEPS.length - 1 ? 'Launch Campaign' : 'Next'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Campaign;