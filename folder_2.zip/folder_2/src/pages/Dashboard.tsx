// // import React from 'react';
// // import { Users, TrendingUp, DollarSign, Mail } from 'lucide-react';

// // const Dashboard = () => {
// //   return (
// //     <div>
// //       <h1 className="text-2xl font-semibold text-gray-800">Dashboard</h1>
// //       <p className="mt-1 text-gray-600">Get an overview of your influencer marketing campaigns</p>
      
// //       <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
// //         {/* Stat cards */}
// //         <div className="overflow-hidden rounded-lg bg-white shadow transition-all duration-300 hover:shadow-md">
// //           <div className="px-4 py-5 sm:p-6">
// //             <div className="flex items-center">
// //               <div className="flex-shrink-0 rounded-md bg-purple-100 p-3">
// //                 <Users className="h-6 w-6 text-purple-600" />
// //               </div>
// //               <div className="ml-5 w-0 flex-1">
// //                 <dl>
// //                   <dt className="text-sm font-medium text-gray-500 truncate">Total Creators</dt>
// //                   <dd className="text-xl font-semibold text-gray-900">1,482</dd>
// //                 </dl>
// //               </div>
// //             </div>
// //           </div>
// //         </div>
        
// //         <div className="overflow-hidden rounded-lg bg-white shadow transition-all duration-300 hover:shadow-md">
// //           <div className="px-4 py-5 sm:p-6">
// //             <div className="flex items-center">
// //               <div className="flex-shrink-0 rounded-md bg-teal-100 p-3">
// //                 <TrendingUp className="h-6 w-6 text-teal-600" />
// //               </div>
// //               <div className="ml-5 w-0 flex-1">
// //                 <dl>
// //                   <dt className="text-sm font-medium text-gray-500 truncate">Active Campaigns</dt>
// //                   <dd className="text-xl font-semibold text-gray-900">12</dd>
// //                 </dl>
// //               </div>
// //             </div>
// //           </div>
// //         </div>
        
// //         <div className="overflow-hidden rounded-lg bg-white shadow transition-all duration-300 hover:shadow-md">
// //           <div className="px-4 py-5 sm:p-6">
// //             <div className="flex items-center">
// //               <div className="flex-shrink-0 rounded-md bg-orange-100 p-3">
// //                 <DollarSign className="h-6 w-6 text-orange-600" />
// //               </div>
// //               <div className="ml-5 w-0 flex-1">
// //                 <dl>
// //                   <dt className="text-sm font-medium text-gray-500 truncate">Budget Spent</dt>
// //                   <dd className="text-xl font-semibold text-gray-900">₹24,500</dd>
// //                 </dl>
// //               </div>
// //             </div>
// //           </div>
// //         </div>
        
// //         <div className="overflow-hidden rounded-lg bg-white shadow transition-all duration-300 hover:shadow-md">
// //           <div className="px-4 py-5 sm:p-6">
// //             <div className="flex items-center">
// //               <div className="flex-shrink-0 rounded-md bg-blue-100 p-3">
// //                 <Mail className="h-6 w-6 text-blue-600" />
// //               </div>
// //               <div className="ml-5 w-0 flex-1">
// //                 <dl>
// //                   <dt className="text-sm font-medium text-gray-500 truncate">Messages Sent</dt>
// //                   <dd className="text-xl font-semibold text-gray-900">342</dd>
// //                 </dl>
// //               </div>
// //             </div>
// //           </div>
// //         </div>
// //       </div>

// //       <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-2">
// //         {/* Recent campaigns */}
// //         <div className="overflow-hidden rounded-lg bg-white shadow">
// //           <div className="border-b border-gray-200 px-4 py-5 sm:px-6">
// //             <h3 className="text-lg font-medium leading-6 text-gray-900">Recent Campaigns</h3>
// //           </div>
// //           <div className="px-4 py-5 sm:p-6">
// //             <div className="space-y-4">
// //               {[
// //                 { name: 'Eco Water Bottle Promotion', status: 'Active', date: 'May 15, 2025' },
// //                 { name: 'Sustainable Clothing Line', status: 'Pending', date: 'May 12, 2025' },
// //                 { name: 'Organic Food Delivery', status: 'Completed', date: 'May 5, 2025' },
// //                 { name: 'Fitness App Launch', status: 'Active', date: 'Apr 28, 2025' },
// //               ].map((campaign, i) => (
// //                 <div key={i} className="flex items-center justify-between rounded-lg border border-gray-100 p-4 transition-all duration-300 hover:bg-gray-50">
// //                   <div>
// //                     <h4 className="font-medium text-gray-900">{campaign.name}</h4>
// //                     <p className="text-sm text-gray-500">Started: {campaign.date}</p>
// //                   </div>
// //                   <span className={`rounded-full px-3 py-1 text-xs font-medium ${
// //                     campaign.status === 'Active' ? 'bg-green-100 text-green-800' :
// //                     campaign.status === 'Pending' ? 'bg-yellow-100 text-yellow-800' :
// //                     'bg-blue-100 text-blue-800'
// //                   }`}>
// //                     {campaign.status}
// //                   </span>
// //                 </div>
// //               ))}
// //             </div>
// //           </div>
// //         </div>

// //         {/* Top performing creators */}
// //         <div className="overflow-hidden rounded-lg bg-white shadow">
// //           <div className="border-b border-gray-200 px-4 py-5 sm:px-6">
// //             <h3 className="text-lg font-medium leading-6 text-gray-900">Top Performing Creators</h3>
// //           </div>
// //           <div className="px-4 py-5 sm:p-6">
// //             <div className="space-y-4">
// //               {[
// //                 { name: 'Priya Sharma', platform: 'Instagram', engagement: '5.8%', followers: '230K' },
// //                 { name: 'Rahul Patel', platform: 'YouTube', engagement: '4.2%', followers: '500K' },
// //                 { name: 'Ananya Desai', platform: 'Instagram', engagement: '6.1%', followers: '125K' },
// //                 { name: 'Vikram Singh', platform: 'TikTok', engagement: '7.2%', followers: '300K' },
// //               ].map((creator, i) => (
// //                 <div key={i} className="flex items-center space-x-4 rounded-lg border border-gray-100 p-4 transition-all duration-300 hover:bg-gray-50">
// //                   <div className="h-12 w-12 flex-shrink-0 overflow-hidden rounded-full bg-gray-200">
// //                     <img 
// //                       src={`https://robohash.org/${creator.username}?set=set4=${encodeURIComponent(creator.name)}`} 
// //                       alt={creator.name}
// //                       className="h-full w-full object-cover"
// //                       onError={(e) => {
// //                         (e.target as HTMLImageElement).src = '';
// //                       }}
// //                     />
// //                   </div>
// //                   <div className="min-w-0 flex-1">
// //                     <p className="font-medium text-gray-900">{creator.name}</p>
// //                     <p className="text-sm text-gray-500">{creator.platform} • {creator.followers} followers</p>
// //                   </div>
// //                   <div className="text-right">
// //                     <p className="text-sm font-medium text-gray-900">{creator.engagement}</p>
// //                     <p className="text-xs text-gray-500">Engagement</p>
// //                   </div>
// //                 </div>
// //               ))}
// //             </div>
// //           </div>
// //         </div>
// //       </div>
// //     </div>
// //   );
// // };

// // export default Dashboard;import React, { useEffect, useState } from 'react';
// import { Users, TrendingUp, DollarSign, Mail, Minus } from 'lucide-react';
// import { useState } from 'react';
// import ChatBot from 'react-simple-chatbot';
// import { ThemeProvider } from 'styled-components';

// const Dashboard = () => {
//   const [isChatOpen, setIsChatOpen] = useState(true);

//   const steps = [
//     {
//       id: '0',
//       message: "Hi there! I'm your AI assistant. Ask me anything about your campaigns.",
//       trigger: '1',
//     },
//     {
//       id: '1',
//       user: true,
//       trigger: '2',
//     },
//     {
//       id: '2',
//       message: "Thanks for your message. I’ll get back to you shortly!",
//       trigger: '1',
//     },
//   ];

//   const theme = {
//     background: '#f9fafb',
//     fontFamily: 'Arial',
//     headerBgColor: '#6366f1',
//     headerFontColor: '#fff',
//     headerFontSize: '16px',
//     botBubbleColor: '#6366f1',
//     botFontColor: '#fff',
//     userBubbleColor: '#e5e7eb',
//     userFontColor: '#000',
//   };

//   return (
//     <div className="p-4">
//       <h1 className="text-2xl font-semibold text-gray-800">Dashboard</h1>
//       <p className="mt-1 text-gray-600">Get an overview of your influencer marketing campaigns</p>

//       <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
//         {/* Stat Cards */}
//         <div className="rounded-lg bg-white shadow px-4 py-5">
//           <div className="flex items-center">
//             <div className="rounded-md bg-purple-100 p-3">
//               <Users className="h-6 w-6 text-purple-600" />
//             </div>
//             <div className="ml-5">
//               <dt className="text-sm font-medium text-gray-500">Total Creators</dt>
//               <dd className="text-xl font-semibold text-gray-900">1,482</dd>
//             </div>
//           </div>
//         </div>
//         <div className="rounded-lg bg-white shadow px-4 py-5">
//           <div className="flex items-center">
//             <div className="rounded-md bg-teal-100 p-3">
//               <TrendingUp className="h-6 w-6 text-teal-600" />
//             </div>
//             <div className="ml-5">
//               <dt className="text-sm font-medium text-gray-500">Active Campaigns</dt>
//               <dd className="text-xl font-semibold text-gray-900">12</dd>
//             </div>
//           </div>
//         </div>
//         <div className="rounded-lg bg-white shadow px-4 py-5">
//           <div className="flex items-center">
//             <div className="rounded-md bg-orange-100 p-3">
//               <DollarSign className="h-6 w-6 text-orange-600" />
//             </div>
//             <div className="ml-5">
//               <dt className="text-sm font-medium text-gray-500">Budget Spent</dt>
//               <dd className="text-xl font-semibold text-gray-900">₹24,500</dd>
//             </div>
//           </div>
//         </div>
//         <div className="rounded-lg bg-white shadow px-4 py-5">
//           <div className="flex items-center">
//             <div className="rounded-md bg-blue-100 p-3">
//               <Mail className="h-6 w-6 text-blue-600" />
//             </div>
//             <div className="ml-5">
//               <dt className="text-sm font-medium text-gray-500">Messages Sent</dt>
//               <dd className="text-xl font-semibold text-gray-900">342</dd>
//             </div>
//           </div>
//         </div>
//       </div>

//       {/* Campaigns & Creators */}
//       <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-2">
//         {/* Recent Campaigns */}
//         <div className="rounded-lg bg-white shadow">
//           <div className="border-b border-gray-200 px-4 py-5">
//             <h3 className="text-lg font-medium text-gray-900">Recent Campaigns</h3>
//           </div>
//           <div className="px-4 py-5 space-y-4">
//             {[
//               { name: 'Eco Water Bottle Promotion', status: 'Active', date: 'May 15, 2025' },
//               { name: 'Sustainable Clothing Line', status: 'Pending', date: 'May 12, 2025' },
//               { name: 'Organic Food Delivery', status: 'Completed', date: 'May 5, 2025' },
//               { name: 'Fitness App Launch', status: 'Active', date: 'Apr 28, 2025' },
//             ].map((campaign, i) => (
//               <div key={i} className="flex justify-between items-center rounded-lg border p-4 hover:bg-gray-50">
//                 <div>
//                   <h4 className="font-medium text-gray-900">{campaign.name}</h4>
//                   <p className="text-sm text-gray-500">Started: {campaign.date}</p>
//                 </div>
//                 <span className={`rounded-full px-3 py-1 text-xs font-medium ${
//                   campaign.status === 'Active' ? 'bg-green-100 text-green-800' :
//                   campaign.status === 'Pending' ? 'bg-yellow-100 text-yellow-800' :
//                   'bg-blue-100 text-blue-800'
//                 }`}>
//                   {campaign.status}
//                 </span>
//               </div>
//             ))}
//           </div>
//         </div>

//         {/* Top Creators */}
//         <div className="rounded-lg bg-white shadow">
//           <div className="border-b border-gray-200 px-4 py-5">
//             <h3 className="text-lg font-medium text-gray-900">Top Performing Creators</h3>
//           </div>
//           <div className="px-4 py-5 space-y-4">
//             {[
//               { name: 'Priya Sharma', platform: 'Instagram', engagement: '5.8%', followers: '230K' },
//               { name: 'Rahul Patel', platform: 'YouTube', engagement: '4.2%', followers: '500K' },
//               { name: 'Ananya Desai', platform: 'Instagram', engagement: '6.1%', followers: '125K' },
//               { name: 'Vikram Singh', platform: 'TikTok', engagement: '7.2%', followers: '300K' },
//             ].map((creator, i) => (
//               <div key={i} className="flex items-center space-x-4 border rounded-lg p-4 hover:bg-gray-50">
//                 <div className="h-12 w-12 rounded-full bg-gray-200 overflow-hidden">
//                   <img
//                     src={`https://robohash.org/${encodeURIComponent(creator.name)}?set=set4`}
//                     alt={creator.name}
//                     className="h-full w-full object-cover"
//                     onError={(e) => ((e.target as HTMLImageElement).src = '')}
//                   />
//                 </div>
//                 <div className="flex-1">
//                   <p className="font-medium text-gray-900">{creator.name}</p>
//                   <p className="text-sm text-gray-500">{creator.platform} • {creator.followers} followers</p>
//                 </div>
//                 <div className="text-right">
//                   <p className="text-sm font-medium text-gray-900">{creator.engagement}</p>
//                   <p className="text-xs text-gray-500">Engagement</p>
//                 </div>
//               </div>
//             ))}
//           </div>
//         </div>
//       </div>

//       {/* 🔽 Collapsible Chatbot Widget */}
//       <div className="fixed bottom-4 right-4 z-50 w-[350px] shadow-lg">
//         <div className="rounded-t-md bg-[#6366f1] text-white px-4 py-2 flex justify-between items-center">
//           <span className="font-semibold"></span>
//           <button onClick={() => setIsChatOpen(!isChatOpen)} className="text-white hover:text-gray-200">
//             {isChatOpen ? <Minus size={18} /> : <span className="text-xl">▲</span>}
//           </button>
//         </div>

//         {isChatOpen && (
//           <ThemeProvider theme={theme}>
//             <ChatBot steps={steps} />
//           </ThemeProvider>
//         )}
//       </div>
//     </div>
//   );
// };

// export default Dashboard;



import { Users, TrendingUp, DollarSign, Mail, Minus } from 'lucide-react';
import { useState } from 'react';
import ChatBot from 'react-simple-chatbot';
import { ThemeProvider } from 'styled-components';
import DynamicResponse from './DynamicResponse'; // Make sure this is defined or imported

const Dashboard = () => {
  const [isChatOpen, setIsChatOpen] = useState(true);

  const steps = [
    {
      id: '0',
      message: "Hi there! I'm your AI assistant. Ask me anything about your campaigns.",
      trigger: '1',
    },
    {
      id: '1',
      user: true,
      trigger: '2',
    },
    {
      id: '2',
      component: <DynamicResponse />,
      waitAction: true,
      asMessage: true,
      trigger: '1',
    },
  ];

  const theme = {
    background: '#f9fafb',
    fontFamily: 'Arial',
    headerBgColor: '#6366f1',
    headerFontColor: '#fff',
    headerFontSize: '16px',
    botBubbleColor: '#6366f1',
    botFontColor: '#fff',
    userBubbleColor: '#e5e7eb',
    userFontColor: '#000',
  };

  return (
    <div className="p-4">
      <h1 className="text-2xl font-semibold text-gray-800">Dashboard</h1>
      <p className="mt-1 text-gray-600">Get an overview of your influencer marketing campaigns</p>

      <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {/* Stat Cards */}
        <div className="rounded-lg bg-white shadow px-4 py-5">
          <div className="flex items-center">
            <div className="rounded-md bg-purple-100 p-3">
              <Users className="h-6 w-6 text-purple-600" />
            </div>
            <div className="ml-5">
              <dt className="text-sm font-medium text-gray-500">Total Creators</dt>
              <dd className="text-xl font-semibold text-gray-900">1,482</dd>
            </div>
          </div>
        </div>
        <div className="rounded-lg bg-white shadow px-4 py-5">
          <div className="flex items-center">
            <div className="rounded-md bg-teal-100 p-3">
              <TrendingUp className="h-6 w-6 text-teal-600" />
            </div>
            <div className="ml-5">
              <dt className="text-sm font-medium text-gray-500">Active Campaigns</dt>
              <dd className="text-xl font-semibold text-gray-900">12</dd>
            </div>
          </div>
        </div>
        <div className="rounded-lg bg-white shadow px-4 py-5">
          <div className="flex items-center">
            <div className="rounded-md bg-orange-100 p-3">
              <DollarSign className="h-6 w-6 text-orange-600" />
            </div>
            <div className="ml-5">
              <dt className="text-sm font-medium text-gray-500">Budget Spent</dt>
              <dd className="text-xl font-semibold text-gray-900">₹24,500</dd>
            </div>
          </div>
        </div>
        <div className="rounded-lg bg-white shadow px-4 py-5">
          <div className="flex items-center">
            <div className="rounded-md bg-blue-100 p-3">
              <Mail className="h-6 w-6 text-blue-600" />
            </div>
            <div className="ml-5">
              <dt className="text-sm font-medium text-gray-500">Messages Sent</dt>
              <dd className="text-xl font-semibold text-gray-900">342</dd>
            </div>
          </div>
        </div>
      </div>

      {/* Campaigns & Creators */}
      <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Recent Campaigns */}
        <div className="rounded-lg bg-white shadow">
          <div className="border-b border-gray-200 px-4 py-5">
            <h3 className="text-lg font-medium text-gray-900">Recent Campaigns</h3>
          </div>
          <div className="px-4 py-5 space-y-4">
            {[
              { name: 'Eco Water Bottle Promotion', status: 'Active', date: 'May 15, 2025' },
              { name: 'Sustainable Clothing Line', status: 'Pending', date: 'May 12, 2025' },
              { name: 'Organic Food Delivery', status: 'Completed', date: 'May 5, 2025' },
              { name: 'Fitness App Launch', status: 'Active', date: 'Apr 28, 2025' },
            ].map((campaign, i) => (
              <div key={i} className="flex justify-between items-center rounded-lg border p-4 hover:bg-gray-50">
                <div>
                  <h4 className="font-medium text-gray-900">{campaign.name}</h4>
                  <p className="text-sm text-gray-500">Started: {campaign.date}</p>
                </div>
                <span className={`rounded-full px-3 py-1 text-xs font-medium ${
                  campaign.status === 'Active' ? 'bg-green-100 text-green-800' :
                  campaign.status === 'Pending' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-blue-100 text-blue-800'
                }`}>
                  {campaign.status}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Top Creators */}
        <div className="rounded-lg bg-white shadow">
          <div className="border-b border-gray-200 px-4 py-5">
            <h3 className="text-lg font-medium text-gray-900">Top Performing Creators</h3>
          </div>
          <div className="px-4 py-5 space-y-4">
            {[
              { name: 'Priya Sharma', platform: 'Instagram', engagement: '5.8%', followers: '230K' },
              { name: 'Rahul Patel', platform: 'YouTube', engagement: '4.2%', followers: '500K' },
              { name: 'Ananya Desai', platform: 'Instagram', engagement: '6.1%', followers: '125K' },
              { name: 'Vikram Singh', platform: 'TikTok', engagement: '7.2%', followers: '300K' },
            ].map((creator, i) => (
              <div key={i} className="flex items-center space-x-4 border rounded-lg p-4 hover:bg-gray-50">
                <div className="h-12 w-12 rounded-full bg-gray-200 overflow-hidden">
                  <img
                    src={`https://robohash.org/${encodeURIComponent(creator.name)}?set=set4`}
                    alt={creator.name}
                    className="h-full w-full object-cover"
                    onError={(e) => ((e.target as HTMLImageElement).src = '')}
                  />
                </div>
                <div className="flex-1">
                  <p className="font-medium text-gray-900">{creator.name}</p>
                  <p className="text-sm text-gray-500">{creator.platform} • {creator.followers} followers</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-gray-900">{creator.engagement}</p>
                  <p className="text-xs text-gray-500">Engagement</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 🔽 Collapsible Chatbot Widget */}
      <div className="fixed bottom-4 right-4 z-50 w-[350px] shadow-lg">
        <div className="rounded-t-md bg-[#6366f1] text-white px-4 py-2 flex justify-between items-center">
          <span className="font-semibold"></span>
          <button onClick={() => setIsChatOpen(!isChatOpen)} className="text-white hover:text-gray-200">
            {isChatOpen ? <Minus size={18} /> : <span className="text-xl">▲</span>}
          </button>
        </div>

        {isChatOpen && (
          <ThemeProvider theme={theme}>
            <ChatBot steps={steps} />
          </ThemeProvider>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
