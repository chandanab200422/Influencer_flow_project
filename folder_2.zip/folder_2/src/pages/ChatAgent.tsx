import ChatBot from 'react-simple-chatbot';
import { ThemeProvider } from 'styled-components';

const steps = [
  { id: '1', message: 'Hi! I’m your AI agent 🤖', trigger: '2' },
  { id: '2', message: 'How can I assist you today?', end: true },
];

const theme = {
  background: '#f5f8fb',
  headerBgColor: '#4F46E5',
  headerFontColor: '#fff',
  headerFontSize: '16px',
  botBubbleColor: '#4F46E5',
  botFontColor: '#fff',
  userBubbleColor: '#fff',
  userFontColor: '#333',
};

const ChatAgent = () => (
  <ThemeProvider theme={theme}>
    <ChatBot steps={steps} floating={true} />
  </ThemeProvider>
);

export default ChatAgent;
