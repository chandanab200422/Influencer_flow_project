import React, { useEffect, useState } from 'react';

const DynamicResponse = ({ steps, triggerNextStep }) => {
  const [response, setResponse] = useState("Let me think...");

  useEffect(() => {
    const fetchAnswer = async () => {
      try {
        const userInput = steps[1].value;

        const res = await fetch("http://localhost:8000/ask", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ query: userInput }),
        });

        const data = await res.json();
        setResponse(data.response || "Sorry, I couldn't understand that.");
      } catch (error) {
        setResponse("");
      }
    };

    fetchAnswer();
  }, [steps]);

  return <div>{response}</div>;
};

export default DynamicResponse;
