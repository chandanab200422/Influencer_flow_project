// import React, { useState, useEffect } from 'react';
// import { useNavigate } from 'react-router-dom';
// import { Search, Filter, Grid, List } from 'lucide-react';
// import FilterPanel from '../components/FilterPanel';
// import CreatorCard, { Creator } from '../components/CreatorCard';
// import { getCreators } from '../services/influencerService';

// const CreatorDiscovery: React.FC = () => {
//   const navigate = useNavigate();
//   const [searchQuery, setSearchQuery] = useState('');
//   const [showFilters, setShowFilters] = useState(false);
//   const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
//   const [creators, setCreators] = useState<Creator[]>([]);
//   const [loading, setLoading] = useState(true);
//   const [activeFilters, setActiveFilters] = useState<any>({});

//   useEffect(() => {
//     loadCreators();
//   }, []);

//   const loadCreators = async (filters = {}) => {
//     setLoading(true);
//     try {
//       const data = await getCreators(filters);
//       setCreators(data);
//     } catch (error) {
//       console.error('Error loading creators:', error);
//     }
//     setLoading(false);
//   };

//   const handleApplyFilters = async (filters: any) => {
//     setActiveFilters(filters);
//     await loadCreators(filters);
//     setShowFilters(false);
//   };

//   const handleCreatorClick = (creator: Creator) => {
//     navigate(`/creator/${creator.id}`);
//   };

//   const filteredCreators = creators.filter(creator =>
//     creator.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
//     creator.niche.some(n => n.toLowerCase().includes(searchQuery.toLowerCase())) ||
//     creator.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
//     creator.username.toLowerCase().includes(searchQuery.toLowerCase())
//   );

//   if (loading) {
//     return (
//       <div className="flex items-center justify-center h-full">
//         <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
//       </div>
//     );
//   }

//   return (
//     <div className="h-full">
//       <div className="mb-6">
//         <h1 className="text-2xl font-semibold text-gray-800">Creator Discovery</h1>
//         <p className="mt-1 text-gray-600">Find the perfect influencers for your brand</p>
//       </div>

//       <div className="flex flex-col lg:flex-row lg:space-x-6">
//         {/* Filters panel */}
//         <div className={`lg:w-1/4 mb-6 lg:mb-0 ${showFilters ? 'block' : 'hidden lg:block'}`}>
//           <FilterPanel onApplyFilters={handleApplyFilters} />
//         </div>

//         {/* Main content */}
//         <div className="lg:w-3/4">
//           {/* Search and filter controls */}
//           <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 space-y-4 sm:space-y-0">
//             <div className="relative flex-1 max-w-md">
//               <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
//                 <Search className="h-5 w-5 text-gray-400" />
//               </div>
//               <input
//                 type="text"
//                 placeholder="Search creators..."
//                 className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-purple-500 focus:border-purple-500 sm:text-sm"
//                 value={searchQuery}
//                 onChange={(e) => setSearchQuery(e.target.value)}
//               />
//             </div>
            
//             <div className="flex items-center space-x-2">
//               <button
//                 onClick={() => setShowFilters(!showFilters)}
//                 className="lg:hidden inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500"
//               >
//                 <Filter className="h-5 w-5 mr-2 text-gray-500" />
//                 Filters
//               </button>
              
//               <div className="bg-white border border-gray-300 rounded-md flex">
//                 <button
//                   onClick={() => setViewMode('grid')}
//                   className={`p-2 ${viewMode === 'grid' ? 'text-purple-600 bg-purple-50' : 'text-gray-500 hover:bg-gray-50'}`}
//                 >
//                   <Grid className="h-5 w-5" />
//                 </button>
//                 {/* <button
//                   onClick={() => setViewMode('list')}
//                   className={`p-2 ${viewMode === 'list' ? 'text-purple-600 bg-purple-50' : 'text-gray-500 hover:bg-gray-50'}`}
//                 >
//                   <List className="h-5 w-5" />
//                 </button> */}
//               </div>
//             </div>
//           </div>

//           {/* Results count */}
//           <p className="text-gray-500 mb-4">Showing {filteredCreators.length} creators</p>

//           {/* Creators grid/list */}
//           {viewMode === 'grid' ? (
//             <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
//               {filteredCreators.map((creator) => (
//                 <CreatorCard 
//                   key={creator.id} 
//                   creator={creator} 
//                   onClick={handleCreatorClick}
//                 />
//               ))}
//             </div>
//           ) : (
//             <div className="space-y-4">
//               {filteredCreators.map((creator) => (
//                 <div 
//                   key={creator.id}
//                   onClick={() => handleCreatorClick(creator)}
//                   className="flex items-center space-x-4 bg-white rounded-lg shadow p-4 cursor-pointer hover:shadow-md transition-shadow duration-300"
//                 >
//                   <div className="h-16 w-16 flex-shrink-0 rounded-full overflow-hidden">
//                     <img 
//                       src={creator.image} 
//                       alt={creator.name}
//                       className="h-full w-full object-cover"
//                       onError={(e) => {
//                         (e.target as HTMLImageElement).src = '';
//                       }}
//                     />
//                   </div>
                  
//                   <div className="flex-1 min-w-0">
//                     <div className="flex items-center justify-between mb-1">
//                       <h3 className="text-sm font-medium text-gray-900 truncate">{creator.name}</h3>
//                       <div className="flex space-x-1">
//                         {creator.platforms.map((platform, i) => (
//                           <span 
//                             key={i}
//                             className="inline-flex items-center rounded-full bg-purple-100 p-1"
//                           >
//                             {platform === 'Instagram' ? (
//                               <Instagram className="h-3 w-3 text-purple-600" />
//                             ) : platform === 'Youtube' ? (
//                               <Youtube className="h-3 w-3 text-purple-600" />
//                             ) : (
//                               <Twitter className="h-3 w-3 text-purple-600" />
//                             )}
//                           </span>
//                         ))}
//                       </div>
//                     </div>
                    
//                     <p className="text-xs text-gray-500 mb-1">
//                       {creator.location} • {creator.niche.join(', ')}
//                     </p>
                    
//                     <p className="text-xs text-gray-600 truncate">{creator.bio}</p>
//                   </div>
                  
//                   <div className="flex items-center space-x-4 text-xs">
//                     <div className="text-center">
//                       <p className="font-semibold">
//                         {creator.followers >= 1000000 
//                           ? `${(creator.followers / 1000000).toFixed(1)}M` 
//                           : `${(creator.followers / 1000).toFixed(1)}K`}
//                       </p>
//                       <p className="text-gray-500">Followers</p>
//                     </div>
                    
//                     <div className="text-center">
//                       <p className="font-semibold">{creator.engagementRate.toFixed(1)}%</p>
//                       <p className="text-gray-500">Engagement</p>
//                     </div>
//                   </div>
//                 </div>
//               ))}
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default CreatorDiscovery;

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Filter, Grid } from 'lucide-react';
import FilterPanel from '../components/FilterPanel';
import CreatorCard, { Creator } from '../components/CreatorCard';
import { getCreators } from '../services/influencerService';
import axios from 'axios';


const CreatorDiscovery: React.FC = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [creators, setCreators] = useState<Creator[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeFilters, setActiveFilters] = useState<any>({});
  const [aiLoading, setAiLoading] = useState(false);

  useEffect(() => {
    loadCreators();
  }, []);

  const loadCreators = async (filters = {}) => {
    setLoading(true);
    try {
      const data = await getCreators(filters);
      setCreators(data);
    } catch (error) {
      console.error('Error loading creators:', error);
    }
    setLoading(false);
  };

  const handleApplyFilters = async (filters: any) => {
    setActiveFilters(filters);
    await loadCreators(filters);
    setShowFilters(false);
  };

  const handleCreatorClick = (creator: Creator) => {
    navigate(`/creator/${creator.id}`);
  };

  const handleAISearch = async () => {
    if (!searchQuery.trim()) return;
    setAiLoading(true);
    try {
      const response = await axios.post(
        'https://api.openai.com/v1/chat/completions',
        {
          model: 'gpt-3.5-turbo',
          messages: [
            {
              role: 'system',
              content: 'You are an assistant that helps to find creators based on user queries.',
            },
            {
              role: 'user',
              content: `Find creators related to: ${searchQuery}`,
            },
          ],
        },
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer YOUR_OPENAI_API_KEY`,
          },
        }
      );

      const aiResponse = response.data.choices[0].message.content;
      // Assuming your backend can handle AI-processed queries
      await loadCreators({ aiQuery: aiResponse });
    } catch (error) {
      console.error('AI Search Error:', error);
    }
    setAiLoading(false);
  };

  const filteredCreators = creators.filter((creator) =>
    creator.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    creator.niche.some((n) => n.toLowerCase().includes(searchQuery.toLowerCase())) ||
    creator.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
    creator.username.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="h-full">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-gray-800">Creator Discovery</h1>
        <p className="mt-1 text-gray-600">Find the perfect influencers for your brand</p>
      </div>

      <div className="flex flex-col lg:flex-row lg:space-x-6">
        {/* Filters panel */}
        <div className={`lg:w-1/4 mb-6 lg:mb-0 ${showFilters ? 'block' : 'hidden lg:block'}`}>
          <FilterPanel onApplyFilters={handleApplyFilters} />
        </div>

        {/* Main content */}
        <div className="lg:w-3/4">
          {/* Search and filter controls */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 space-y-4 sm:space-y-0">
            <div className="relative flex-1 max-w-md">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search creators..."
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-purple-500 focus:border-purple-500 sm:text-sm"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <button
                onClick={handleAISearch}
                className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-purple-500 text-white px-3 py-1 rounded-md text-sm"
                disabled={aiLoading}
              >
                {aiLoading ? 'Searching...' : 'AI Search'}
              </button>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="lg:hidden inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500"
              >
                <Filter className="h-5 w-5 mr-2 text-gray-500" />
                Filters
              </button>

              <div className="bg-white border border-gray-300 rounded-md flex">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-2 ${viewMode === 'grid' ? 'text-purple-600 bg-purple-50' : 'text-gray-500 hover:bg-gray-50'}`}
                >
                  <Grid className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>

          {/* Results count */}
          <p className="text-gray-500 mb-4">Showing {filteredCreators.length} creators</p>

          {/* Creators grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCreators.map((creator) => (
              <CreatorCard key={creator.id} creator={creator} onClick={handleCreatorClick} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreatorDiscovery;
